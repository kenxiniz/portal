" -*- vim -*-
"          File: .vimrc
"   Description: sspark's personal Vim settings.
"set fileencodings=euc-kr
"set encoding=cp949
set ts=2
"set et
set sw=2
"set smarttab
set wrap
set expandtab

" select colorschems
" blue darkblue default delek desert elflord evening koehler morning murphy pablo peachpuff ron shine torte zellner
"
"colorscheme pyte
colorscheme desert
"colorscheme slate
"colorscheme elflord
"colorscheme morning
"colorscheme shine
"colorscheme torte

" blue.vim      default.vim  desert.vim   evening.vim  molokai.vim  murphy.vim  peachpuff.vim  ron.vim    slate.vim  zellner.vim darkblue.vim  delek.vim
" elflord.vim  koehler.vim  morning.vim  pablo.vim   shine.vim  torte.vim

" Turn on the verboseness to see everything is doing.
"set verbose=9

" Stop the annoying bell, use the visual-bell instead.
set visualbell

" Show (partial) command in status line.
set showcmd

" Allow backspacing over everything in insert mode.
set bs=2

" Always set autoindenting on.
set ai

" Don't wrap lines at the edge of the screen.
set nowrap

" Keep 50 lines of command line history.
set history=50

" Show the cursor position all the time.
set ruler

" Do incremental searching.
"set incsearch

" Set ignorecase on.
" set ignorecase

" Set 'g' substitute flag on.
set gdefault

" make backup files
"set backup

" Set the command line to one line high.
set cmdheight=1

" set cindent for the c like files

" set status line
set statusline=[%02n]\ %f\ %(\[%M%R%H]%)%=\ %4l,%02c%2V\ %P%*

" Always display a status line at the bottom of window.
set laststatus=2

" Set the cinoptions. Use the default for everything except the ( option.
set cinoptions=(0

" showmatch: Show the matching bracket for the last ')'?
set showmatch

" allow tilde (~) to act as an operator -- ~w, etc.
"set tildeop

" highlight search string
set hlsearch

" set tag files.
"if has("Win32")
"  set tags=./tags,../tags,q:/Develop/Src/tags,q:/Products/Src/tags,q:/Products/Java/tags
"else
"  set tags=./tags,../tags,/mnt/Disc/Develop/Src/tags,/mnt/Disc/Products/Src/tags,/mnt/Disc/Products/Java/tags
"endif
"set tags =./tags,../tags,../../tags,../../../../tags
set tags=./tags

" set list
"set listchars=eol:$,tab:>-,trail:-,extends:>,precedes:<
"set list!

if has("gui")
  " set the gui options to:
  "   g: grey inactive menu items
  "   m: display menu bar
  "   r: display scrollbar on right side of window
  "   b: display scrollbar at bottom of window
  "   t: enable tearoff menus on Win32
  "   T: enable toolbar on Win32
  set go=gmrb
endif

" save backup files to ./.backup/ if exist
set backupdir=./.backup,~/.vibak,/tmp
" if working directroy is not writable, where to write swap files?
set directory=.,./backup,~/.vibak,/tmp

" when split window, use opened window if the file is already opened
"set switchbuf=useopen

" keep the contents of old buffers when switching to another file
set hidden

" backspace can delete also
set backspace=indent,eol,start


" ************************************************************
" C O M M A N D S
"

" ************************************************************
" K E Y   M A P P I N G S
"
set winaltkeys=no
nmap <M-Space> :simalt ~<CR>
" shortcut to navigate windows
map <C-J> <C-W>j<C-W>_
map <C-K> <C-W>k<C-W>_
map <C-H> <C-W>h
map <C-L> <C-W>l
set wmh=0 " set the mimimum window height to 0
set wmw=0
" multiple file navigation
map <C-N> <ESC>:bn <CR>
map <C-P> <ESC>:bp <CR>
map <C-D> <ESC>:%s/\s*$//


" Make tab in v mode work like I think it should (keep highlighting):
"vmap <tab> >gv
"vmap <s-tab> <gv
" shifting blocks visually
vnoremap < <gv
vnoremap > >gv

" make it easy to update/reload .vimrc
:nmap ,s :source ~/.vimrc
:nmap ,v :e      ~/.vimrc


" easy edit files in the same directory as the current file
if has('unix')
    map ,e :e <C-R>=expand("%:p:h") . "/" <CR>
else
    map ,e :e <C-R>=expand("%:p:h") . "\\" <CR>
endif


" ************************************************************
" A B B R E V I A T I O N
"
ab #b /*******************************************************************
ab #e <space>******************************************************************/
ab #i #include

:source ~/.vim/a.vim
"set nu


" tempoary
set tags=~/dev/eflwebview_tempwork/tags
