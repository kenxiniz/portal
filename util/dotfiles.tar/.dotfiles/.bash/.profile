#!/usr/bin/env bash
# netj's bash configuration
# Author: Jaeho Shin <netj@sparcs.kaist.ac.kr>
# Created: 2000-10-20
# Reformed: 2004-05-28

# load local settings and modules

export PATH="/home/kenshin.choi/blink/depot_tools":"/home/kenshin.choi/util/tools":"/usr/p4bin":"/opt/node/bin":$PATH
alias gos='ssh -X 165.213.93.55'
for REPLY in ~/.bash_local ~/.bash/.loader; do
    [ -f $REPLY ] && . $REPLY
done



export ftp_proxy=
export http_proxy=
export https_proxy=
export no_proxy="10.113.63.117,165.213.149.200,10.113.138.88,10.113.136.32,168.219.244.109,10.113.136.26,168.219.245.165"

export GIT_SSL_NO_VERIFY=true
export NO_AUTH_BOTO_CONFIG=~/.boto

